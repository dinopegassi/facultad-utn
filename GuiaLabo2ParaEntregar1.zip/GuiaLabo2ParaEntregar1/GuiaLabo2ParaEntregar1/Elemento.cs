﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuiaLabo2ParaEntregar1
{
    abstract internal class Elemento
    {
        public int PosInit { get; protected set; }
        public int PosFinal { get; protected set; }

        public Elemento()
        {            
        }
        abstract  public void Evaluar(Jugador jugador);
    }
}
