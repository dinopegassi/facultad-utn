﻿using System;

namespace MyApp // Note: actual namespace depends on the project name.
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(987 / 2);
            Console.ReadKey();
            //string[] names = new string[] { "name1", "name2", "name3" };
            //int index;
            //for (int i = 0; i < names.Length; i++)
            //{
            //    Random rnd = new Random();
            //    index = rnd.Next(names.Length);
            //    Console.WriteLine($"Name: {names[index]}");
            //}
            //int index = rnd.Next(names.Length);
            //Console.WriteLine($"Name: {names[index]}");

            //for (int i = 0; i < names.Length; i++)
            //{
            //    Console.WriteLine(" Name : {0}", names[index]);
            //}
            //Console.ReadKey();
        }
    }
}