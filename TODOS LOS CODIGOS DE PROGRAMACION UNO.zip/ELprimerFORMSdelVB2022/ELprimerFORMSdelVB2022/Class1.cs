﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELprimerFORMSdelVB2022
{
    internal class Class1
    {
        private double kilometrosRecorridos;
        private int diaMenorRecorrido;
        private int diaMayorRecorrido;
        private int cantidadDeViajes;
        private int numUnidad;
        public int NumUnidad
        {
            get
            {
                return numUnidad;
            }
        }
        public int DiaMayorKm
        {
            get
            {
                return diaMenorRecorrido;
            }
        }
    }
}
