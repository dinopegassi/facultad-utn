﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2Guia1Ej1
{
    internal class GestorDeEncuestas
    {
        public Alumno MayorPuntaje
        {
            get;private set;
        }
        public Alumno MenorPuntaje
        {
            get; private set;
        }

        public void RegistrarEncuesta(Alumno alumno)
        {

        }
        public int CantidadMayorAdiez()
        {
            return 0;
        }
        public int CantidadMenorAdiez()
        {
            return 0;
        }
        public double PromedioTSP()
        {
            return 0;
        }
        public Alumno[] ListarEncuestados()
        {
            return null;
        }
        public Alumno AlumnoMayorPuntaje()
        {
            return null;
        }
    }
}
