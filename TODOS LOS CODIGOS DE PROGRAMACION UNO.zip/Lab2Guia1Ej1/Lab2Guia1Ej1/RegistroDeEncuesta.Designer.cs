﻿namespace Lab2Guia1Ej1
{
    partial class FormRegistroDeEncuesta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxDatosAlumno = new System.Windows.Forms.GroupBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBoxConsulta1 = new System.Windows.Forms.GroupBox();
            this.groupBoxConsulta2 = new System.Windows.Forms.GroupBox();
            this.groupBoxConsulta4 = new System.Windows.Forms.GroupBox();
            this.groupBoxConsulta3 = new System.Windows.Forms.GroupBox();
            this.radioButtonA1 = new System.Windows.Forms.RadioButton();
            this.radioButtonA2 = new System.Windows.Forms.RadioButton();
            this.radioButtonA4 = new System.Windows.Forms.RadioButton();
            this.radioButtonA3 = new System.Windows.Forms.RadioButton();
            this.radioButtonB3 = new System.Windows.Forms.RadioButton();
            this.radioButtonB4 = new System.Windows.Forms.RadioButton();
            this.radioButtonB2 = new System.Windows.Forms.RadioButton();
            this.radioButtonB1 = new System.Windows.Forms.RadioButton();
            this.radioButtonC1 = new System.Windows.Forms.RadioButton();
            this.radioButtonC2 = new System.Windows.Forms.RadioButton();
            this.radioButtonC4 = new System.Windows.Forms.RadioButton();
            this.radioButtonC3 = new System.Windows.Forms.RadioButton();
            this.buttonConfirmarRegistro = new System.Windows.Forms.Button();
            this.labelNombre = new System.Windows.Forms.Label();
            this.labelCarrera = new System.Windows.Forms.Label();
            this.labelAnio = new System.Windows.Forms.Label();
            this.textBoxNombre = new System.Windows.Forms.TextBox();
            this.comboBoxCarrera = new System.Windows.Forms.ComboBox();
            this.numericUpDownAnio = new System.Windows.Forms.NumericUpDown();
            this.groupBoxDatosAlumno.SuspendLayout();
            this.groupBoxConsulta1.SuspendLayout();
            this.groupBoxConsulta2.SuspendLayout();
            this.groupBoxConsulta4.SuspendLayout();
            this.groupBoxConsulta3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAnio)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxDatosAlumno
            // 
            this.groupBoxDatosAlumno.Controls.Add(this.numericUpDownAnio);
            this.groupBoxDatosAlumno.Controls.Add(this.comboBoxCarrera);
            this.groupBoxDatosAlumno.Controls.Add(this.textBoxNombre);
            this.groupBoxDatosAlumno.Controls.Add(this.labelAnio);
            this.groupBoxDatosAlumno.Controls.Add(this.labelCarrera);
            this.groupBoxDatosAlumno.Controls.Add(this.labelNombre);
            this.groupBoxDatosAlumno.Location = new System.Drawing.Point(12, 12);
            this.groupBoxDatosAlumno.Name = "groupBoxDatosAlumno";
            this.groupBoxDatosAlumno.Size = new System.Drawing.Size(776, 100);
            this.groupBoxDatosAlumno.TabIndex = 0;
            this.groupBoxDatosAlumno.TabStop = false;
            this.groupBoxDatosAlumno.Text = "Datos Del Alumno";
            // 
            // groupBoxConsulta1
            // 
            this.groupBoxConsulta1.Controls.Add(this.radioButtonC1);
            this.groupBoxConsulta1.Controls.Add(this.radioButtonB1);
            this.groupBoxConsulta1.Controls.Add(this.radioButtonA1);
            this.groupBoxConsulta1.Location = new System.Drawing.Point(12, 118);
            this.groupBoxConsulta1.Name = "groupBoxConsulta1";
            this.groupBoxConsulta1.Size = new System.Drawing.Size(355, 100);
            this.groupBoxConsulta1.TabIndex = 1;
            this.groupBoxConsulta1.TabStop = false;
            this.groupBoxConsulta1.Text = "Consulta 1";
            // 
            // groupBoxConsulta2
            // 
            this.groupBoxConsulta2.Controls.Add(this.radioButtonC2);
            this.groupBoxConsulta2.Controls.Add(this.radioButtonB2);
            this.groupBoxConsulta2.Controls.Add(this.radioButtonA2);
            this.groupBoxConsulta2.Location = new System.Drawing.Point(433, 118);
            this.groupBoxConsulta2.Name = "groupBoxConsulta2";
            this.groupBoxConsulta2.Size = new System.Drawing.Size(355, 100);
            this.groupBoxConsulta2.TabIndex = 0;
            this.groupBoxConsulta2.TabStop = false;
            this.groupBoxConsulta2.Text = "Consulta 2";
            // 
            // groupBoxConsulta4
            // 
            this.groupBoxConsulta4.Controls.Add(this.radioButtonC4);
            this.groupBoxConsulta4.Controls.Add(this.radioButtonB4);
            this.groupBoxConsulta4.Controls.Add(this.radioButtonA4);
            this.groupBoxConsulta4.Location = new System.Drawing.Point(433, 224);
            this.groupBoxConsulta4.Name = "groupBoxConsulta4";
            this.groupBoxConsulta4.Size = new System.Drawing.Size(355, 100);
            this.groupBoxConsulta4.TabIndex = 0;
            this.groupBoxConsulta4.TabStop = false;
            this.groupBoxConsulta4.Text = "Consulta 4";
            // 
            // groupBoxConsulta3
            // 
            this.groupBoxConsulta3.Controls.Add(this.radioButtonC3);
            this.groupBoxConsulta3.Controls.Add(this.radioButtonB3);
            this.groupBoxConsulta3.Controls.Add(this.radioButtonA3);
            this.groupBoxConsulta3.Location = new System.Drawing.Point(12, 224);
            this.groupBoxConsulta3.Name = "groupBoxConsulta3";
            this.groupBoxConsulta3.Size = new System.Drawing.Size(355, 100);
            this.groupBoxConsulta3.TabIndex = 0;
            this.groupBoxConsulta3.TabStop = false;
            this.groupBoxConsulta3.Text = "Consulta 3";
            // 
            // radioButtonA1
            // 
            this.radioButtonA1.AutoSize = true;
            this.radioButtonA1.Location = new System.Drawing.Point(6, 19);
            this.radioButtonA1.Name = "radioButtonA1";
            this.radioButtonA1.Size = new System.Drawing.Size(32, 17);
            this.radioButtonA1.TabIndex = 4;
            this.radioButtonA1.TabStop = true;
            this.radioButtonA1.Text = "A";
            this.radioButtonA1.UseVisualStyleBackColor = true;
            // 
            // radioButtonA2
            // 
            this.radioButtonA2.AutoSize = true;
            this.radioButtonA2.Location = new System.Drawing.Point(6, 19);
            this.radioButtonA2.Name = "radioButtonA2";
            this.radioButtonA2.Size = new System.Drawing.Size(32, 17);
            this.radioButtonA2.TabIndex = 7;
            this.radioButtonA2.TabStop = true;
            this.radioButtonA2.Text = "A";
            this.radioButtonA2.UseVisualStyleBackColor = true;
            // 
            // radioButtonA4
            // 
            this.radioButtonA4.AutoSize = true;
            this.radioButtonA4.Location = new System.Drawing.Point(6, 19);
            this.radioButtonA4.Name = "radioButtonA4";
            this.radioButtonA4.Size = new System.Drawing.Size(32, 17);
            this.radioButtonA4.TabIndex = 13;
            this.radioButtonA4.TabStop = true;
            this.radioButtonA4.Text = "A";
            this.radioButtonA4.UseVisualStyleBackColor = true;
            // 
            // radioButtonA3
            // 
            this.radioButtonA3.AutoSize = true;
            this.radioButtonA3.Location = new System.Drawing.Point(6, 19);
            this.radioButtonA3.Name = "radioButtonA3";
            this.radioButtonA3.Size = new System.Drawing.Size(32, 17);
            this.radioButtonA3.TabIndex = 10;
            this.radioButtonA3.TabStop = true;
            this.radioButtonA3.Text = "A";
            this.radioButtonA3.UseVisualStyleBackColor = true;
            // 
            // radioButtonB3
            // 
            this.radioButtonB3.AutoSize = true;
            this.radioButtonB3.Location = new System.Drawing.Point(6, 42);
            this.radioButtonB3.Name = "radioButtonB3";
            this.radioButtonB3.Size = new System.Drawing.Size(32, 17);
            this.radioButtonB3.TabIndex = 11;
            this.radioButtonB3.TabStop = true;
            this.radioButtonB3.Text = "B";
            this.radioButtonB3.UseVisualStyleBackColor = true;
            // 
            // radioButtonB4
            // 
            this.radioButtonB4.AutoSize = true;
            this.radioButtonB4.Location = new System.Drawing.Point(6, 42);
            this.radioButtonB4.Name = "radioButtonB4";
            this.radioButtonB4.Size = new System.Drawing.Size(32, 17);
            this.radioButtonB4.TabIndex = 14;
            this.radioButtonB4.TabStop = true;
            this.radioButtonB4.Text = "B";
            this.radioButtonB4.UseVisualStyleBackColor = true;
            // 
            // radioButtonB2
            // 
            this.radioButtonB2.AutoSize = true;
            this.radioButtonB2.Location = new System.Drawing.Point(6, 42);
            this.radioButtonB2.Name = "radioButtonB2";
            this.radioButtonB2.Size = new System.Drawing.Size(32, 17);
            this.radioButtonB2.TabIndex = 8;
            this.radioButtonB2.TabStop = true;
            this.radioButtonB2.Text = "B";
            this.radioButtonB2.UseVisualStyleBackColor = true;
            // 
            // radioButtonB1
            // 
            this.radioButtonB1.AutoSize = true;
            this.radioButtonB1.Location = new System.Drawing.Point(6, 42);
            this.radioButtonB1.Name = "radioButtonB1";
            this.radioButtonB1.Size = new System.Drawing.Size(32, 17);
            this.radioButtonB1.TabIndex = 5;
            this.radioButtonB1.TabStop = true;
            this.radioButtonB1.Text = "B";
            this.radioButtonB1.UseVisualStyleBackColor = true;
            // 
            // radioButtonC1
            // 
            this.radioButtonC1.AutoSize = true;
            this.radioButtonC1.Location = new System.Drawing.Point(6, 65);
            this.radioButtonC1.Name = "radioButtonC1";
            this.radioButtonC1.Size = new System.Drawing.Size(32, 17);
            this.radioButtonC1.TabIndex = 6;
            this.radioButtonC1.TabStop = true;
            this.radioButtonC1.Text = "C";
            this.radioButtonC1.UseVisualStyleBackColor = true;
            // 
            // radioButtonC2
            // 
            this.radioButtonC2.AutoSize = true;
            this.radioButtonC2.Location = new System.Drawing.Point(6, 65);
            this.radioButtonC2.Name = "radioButtonC2";
            this.radioButtonC2.Size = new System.Drawing.Size(32, 17);
            this.radioButtonC2.TabIndex = 9;
            this.radioButtonC2.TabStop = true;
            this.radioButtonC2.Text = "C";
            this.radioButtonC2.UseVisualStyleBackColor = true;
            // 
            // radioButtonC4
            // 
            this.radioButtonC4.AutoSize = true;
            this.radioButtonC4.Location = new System.Drawing.Point(6, 65);
            this.radioButtonC4.Name = "radioButtonC4";
            this.radioButtonC4.Size = new System.Drawing.Size(32, 17);
            this.radioButtonC4.TabIndex = 15;
            this.radioButtonC4.TabStop = true;
            this.radioButtonC4.Text = "C";
            this.radioButtonC4.UseVisualStyleBackColor = true;
            // 
            // radioButtonC3
            // 
            this.radioButtonC3.AutoSize = true;
            this.radioButtonC3.Location = new System.Drawing.Point(6, 65);
            this.radioButtonC3.Name = "radioButtonC3";
            this.radioButtonC3.Size = new System.Drawing.Size(32, 17);
            this.radioButtonC3.TabIndex = 12;
            this.radioButtonC3.TabStop = true;
            this.radioButtonC3.Text = "C";
            this.radioButtonC3.UseVisualStyleBackColor = true;
            // 
            // buttonConfirmarRegistro
            // 
            this.buttonConfirmarRegistro.Location = new System.Drawing.Point(485, 384);
            this.buttonConfirmarRegistro.Name = "buttonConfirmarRegistro";
            this.buttonConfirmarRegistro.Size = new System.Drawing.Size(226, 23);
            this.buttonConfirmarRegistro.TabIndex = 16;
            this.buttonConfirmarRegistro.Text = "Confirmar Registro";
            this.buttonConfirmarRegistro.UseVisualStyleBackColor = true;
            // 
            // labelNombre
            // 
            this.labelNombre.AutoSize = true;
            this.labelNombre.Location = new System.Drawing.Point(34, 28);
            this.labelNombre.Name = "labelNombre";
            this.labelNombre.Size = new System.Drawing.Size(44, 13);
            this.labelNombre.TabIndex = 3;
            this.labelNombre.Text = "Nombre";
            // 
            // labelCarrera
            // 
            this.labelCarrera.AutoSize = true;
            this.labelCarrera.Location = new System.Drawing.Point(34, 57);
            this.labelCarrera.Name = "labelCarrera";
            this.labelCarrera.Size = new System.Drawing.Size(41, 13);
            this.labelCarrera.TabIndex = 4;
            this.labelCarrera.Text = "Carrera";
            // 
            // labelAnio
            // 
            this.labelAnio.AutoSize = true;
            this.labelAnio.Location = new System.Drawing.Point(516, 57);
            this.labelAnio.Name = "labelAnio";
            this.labelAnio.Size = new System.Drawing.Size(26, 13);
            this.labelAnio.TabIndex = 5;
            this.labelAnio.Text = "Año";
            // 
            // textBoxNombre
            // 
            this.textBoxNombre.Location = new System.Drawing.Point(134, 20);
            this.textBoxNombre.Name = "textBoxNombre";
            this.textBoxNombre.Size = new System.Drawing.Size(325, 20);
            this.textBoxNombre.TabIndex = 1;
            // 
            // comboBoxCarrera
            // 
            this.comboBoxCarrera.FormattingEnabled = true;
            this.comboBoxCarrera.Items.AddRange(new object[] {
            "TSP",
            "TSIA",
            "TSEVMA"});
            this.comboBoxCarrera.Location = new System.Drawing.Point(134, 54);
            this.comboBoxCarrera.Name = "comboBoxCarrera";
            this.comboBoxCarrera.Size = new System.Drawing.Size(325, 21);
            this.comboBoxCarrera.TabIndex = 2;
            // 
            // numericUpDownAnio
            // 
            this.numericUpDownAnio.Location = new System.Drawing.Point(579, 54);
            this.numericUpDownAnio.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.numericUpDownAnio.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownAnio.Name = "numericUpDownAnio";
            this.numericUpDownAnio.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownAnio.TabIndex = 3;
            this.numericUpDownAnio.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // FormRegistroDeEncuesta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonConfirmarRegistro);
            this.Controls.Add(this.groupBoxConsulta4);
            this.Controls.Add(this.groupBoxConsulta3);
            this.Controls.Add(this.groupBoxConsulta2);
            this.Controls.Add(this.groupBoxConsulta1);
            this.Controls.Add(this.groupBoxDatosAlumno);
            this.Name = "FormRegistroDeEncuesta";
            this.Text = "Registro De Encuesta";
            this.groupBoxDatosAlumno.ResumeLayout(false);
            this.groupBoxDatosAlumno.PerformLayout();
            this.groupBoxConsulta1.ResumeLayout(false);
            this.groupBoxConsulta1.PerformLayout();
            this.groupBoxConsulta2.ResumeLayout(false);
            this.groupBoxConsulta2.PerformLayout();
            this.groupBoxConsulta4.ResumeLayout(false);
            this.groupBoxConsulta4.PerformLayout();
            this.groupBoxConsulta3.ResumeLayout(false);
            this.groupBoxConsulta3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAnio)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxDatosAlumno;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox groupBoxConsulta1;
        private System.Windows.Forms.GroupBox groupBoxConsulta2;
        private System.Windows.Forms.GroupBox groupBoxConsulta4;
        private System.Windows.Forms.GroupBox groupBoxConsulta3;
        private System.Windows.Forms.RadioButton radioButtonC1;
        private System.Windows.Forms.RadioButton radioButtonB1;
        private System.Windows.Forms.RadioButton radioButtonA1;
        private System.Windows.Forms.RadioButton radioButtonC2;
        private System.Windows.Forms.RadioButton radioButtonB2;
        private System.Windows.Forms.RadioButton radioButtonA2;
        private System.Windows.Forms.RadioButton radioButtonC4;
        private System.Windows.Forms.RadioButton radioButtonB4;
        private System.Windows.Forms.RadioButton radioButtonA4;
        private System.Windows.Forms.RadioButton radioButtonC3;
        private System.Windows.Forms.RadioButton radioButtonB3;
        private System.Windows.Forms.RadioButton radioButtonA3;
        private System.Windows.Forms.Button buttonConfirmarRegistro;
        private System.Windows.Forms.Label labelNombre;
        private System.Windows.Forms.ComboBox comboBoxCarrera;
        private System.Windows.Forms.TextBox textBoxNombre;
        private System.Windows.Forms.Label labelAnio;
        private System.Windows.Forms.Label labelCarrera;
        private System.Windows.Forms.NumericUpDown numericUpDownAnio;
    }
}