﻿namespace Lab2Guia1Ej1
{
    partial class FormSistemaEncuestas
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonRegistrarEncuesta = new System.Windows.Forms.Button();
            this.buttonListarAlumno = new System.Windows.Forms.Button();
            this.labelCantidadMenoresAdiez = new System.Windows.Forms.Label();
            this.labelCantidadMenoresAcero = new System.Windows.Forms.Label();
            this.labelPromedioTSP = new System.Windows.Forms.Label();
            this.labelAlumnoMenorPuntaje = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.labelAlumnoMayorPuntaje = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonRegistrarEncuesta
            // 
            this.buttonRegistrarEncuesta.Location = new System.Drawing.Point(209, 42);
            this.buttonRegistrarEncuesta.Name = "buttonRegistrarEncuesta";
            this.buttonRegistrarEncuesta.Size = new System.Drawing.Size(116, 23);
            this.buttonRegistrarEncuesta.TabIndex = 0;
            this.buttonRegistrarEncuesta.Text = "Registrar Encuesta";
            this.buttonRegistrarEncuesta.UseVisualStyleBackColor = true;
            // 
            // buttonListarAlumno
            // 
            this.buttonListarAlumno.Location = new System.Drawing.Point(209, 71);
            this.buttonListarAlumno.Name = "buttonListarAlumno";
            this.buttonListarAlumno.Size = new System.Drawing.Size(116, 23);
            this.buttonListarAlumno.TabIndex = 1;
            this.buttonListarAlumno.Text = "Listar Alumno";
            this.buttonListarAlumno.UseVisualStyleBackColor = true;
            // 
            // labelCantidadMenoresAdiez
            // 
            this.labelCantidadMenoresAdiez.AutoSize = true;
            this.labelCantidadMenoresAdiez.Location = new System.Drawing.Point(96, 135);
            this.labelCantidadMenoresAdiez.Name = "labelCantidadMenoresAdiez";
            this.labelCantidadMenoresAdiez.Size = new System.Drawing.Size(126, 13);
            this.labelCantidadMenoresAdiez.TabIndex = 2;
            this.labelCantidadMenoresAdiez.Text = "Cantidad Mayores A Diez";
            // 
            // labelCantidadMenoresAcero
            // 
            this.labelCantidadMenoresAcero.AutoSize = true;
            this.labelCantidadMenoresAcero.Location = new System.Drawing.Point(96, 170);
            this.labelCantidadMenoresAcero.Name = "labelCantidadMenoresAcero";
            this.labelCantidadMenoresAcero.Size = new System.Drawing.Size(128, 13);
            this.labelCantidadMenoresAcero.TabIndex = 4;
            this.labelCantidadMenoresAcero.Text = "Cantidad Menores A Cero";
            // 
            // labelPromedioTSP
            // 
            this.labelPromedioTSP.AutoSize = true;
            this.labelPromedioTSP.Location = new System.Drawing.Point(96, 203);
            this.labelPromedioTSP.Name = "labelPromedioTSP";
            this.labelPromedioTSP.Size = new System.Drawing.Size(75, 13);
            this.labelPromedioTSP.TabIndex = 5;
            this.labelPromedioTSP.Text = "Promedio TSP";
            // 
            // labelAlumnoMenorPuntaje
            // 
            this.labelAlumnoMenorPuntaje.AutoSize = true;
            this.labelAlumnoMenorPuntaje.Location = new System.Drawing.Point(96, 267);
            this.labelAlumnoMenorPuntaje.Name = "labelAlumnoMenorPuntaje";
            this.labelAlumnoMenorPuntaje.Size = new System.Drawing.Size(114, 13);
            this.labelAlumnoMenorPuntaje.TabIndex = 6;
            this.labelAlumnoMenorPuntaje.Text = "Alumno Menor Puntaje";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(431, 235);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(10, 13);
            this.label10.TabIndex = 11;
            this.label10.Text = "-";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(431, 135);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(10, 13);
            this.label11.TabIndex = 12;
            this.label11.Text = "-";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(431, 170);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(10, 13);
            this.label12.TabIndex = 13;
            this.label12.Text = "-";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(431, 203);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(10, 13);
            this.label13.TabIndex = 14;
            this.label13.Text = "-";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(431, 267);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(10, 13);
            this.label14.TabIndex = 15;
            this.label14.Text = "-";
            // 
            // labelAlumnoMayorPuntaje
            // 
            this.labelAlumnoMayorPuntaje.AutoSize = true;
            this.labelAlumnoMayorPuntaje.Location = new System.Drawing.Point(96, 235);
            this.labelAlumnoMayorPuntaje.Name = "labelAlumnoMayorPuntaje";
            this.labelAlumnoMayorPuntaje.Size = new System.Drawing.Size(113, 13);
            this.labelAlumnoMayorPuntaje.TabIndex = 16;
            this.labelAlumnoMayorPuntaje.Text = "Alumno Mayor Puntaje";
            // 
            // FormSistemaEncuestas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelAlumnoMayorPuntaje);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.labelAlumnoMenorPuntaje);
            this.Controls.Add(this.labelPromedioTSP);
            this.Controls.Add(this.labelCantidadMenoresAcero);
            this.Controls.Add(this.labelCantidadMenoresAdiez);
            this.Controls.Add(this.buttonListarAlumno);
            this.Controls.Add(this.buttonRegistrarEncuesta);
            this.Name = "FormSistemaEncuestas";
            this.Text = "Sistema De Encuestas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonRegistrarEncuesta;
        private System.Windows.Forms.Button buttonListarAlumno;
        private System.Windows.Forms.Label labelCantidadMenoresAdiez;
        private System.Windows.Forms.Label labelCantidadMenoresAcero;
        private System.Windows.Forms.Label labelPromedioTSP;
        private System.Windows.Forms.Label labelAlumnoMenorPuntaje;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label labelAlumnoMayorPuntaje;
    }
}

