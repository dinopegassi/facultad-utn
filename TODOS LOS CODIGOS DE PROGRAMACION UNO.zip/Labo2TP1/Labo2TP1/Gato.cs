﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo2TP1
{
    internal class Gato:Animal
    {
        public Gato(int[] posicion) : base(posicion)
        {
        }
        public override void Comer()
        {
            throw new NotImplementedException();
        }
        public override void Mover()
        {
            throw new NotImplementedException();
        }
        public override void Vivir()
        {
            throw new NotImplementedException();
        }
    }

    
}
