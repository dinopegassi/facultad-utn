﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo2TP1
{
    internal class Isla
    {
        public int Dias { get; private set; }
        public int Pasos { get; private set; }
        public Raton[] Ratones { get; private set; }
        public Queso[] Quesos { get; private set; }

        public void HacerUnPaso()
        {

        }
        public void DistribuirAlimento(int cant)
        {

        }
        public void AgregarRatones()
        {

        }
    }
}
