﻿namespace LaboratorioTP3Ejercicio2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLocal = new System.Windows.Forms.Button();
            this.btnVisitante = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.labLocal = new System.Windows.Forms.Label();
            this.labVisitante = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnLocal
            // 
            this.btnLocal.Location = new System.Drawing.Point(216, 40);
            this.btnLocal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnLocal.Name = "btnLocal";
            this.btnLocal.Size = new System.Drawing.Size(132, 22);
            this.btnLocal.TabIndex = 0;
            this.btnLocal.Text = "Agregar Equipo Local";
            this.btnLocal.UseVisualStyleBackColor = true;
            // 
            // btnVisitante
            // 
            this.btnVisitante.Location = new System.Drawing.Point(573, 40);
            this.btnVisitante.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnVisitante.Name = "btnVisitante";
            this.btnVisitante.Size = new System.Drawing.Size(132, 22);
            this.btnVisitante.TabIndex = 1;
            this.btnVisitante.Text = "Agregar Equipo Visitante";
            this.btnVisitante.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(467, 43);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(110, 43);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 3;
            // 
            // labLocal
            // 
            this.labLocal.AutoSize = true;
            this.labLocal.Location = new System.Drawing.Point(55, 45);
            this.labLocal.Name = "labLocal";
            this.labLocal.Size = new System.Drawing.Size(33, 13);
            this.labLocal.TabIndex = 4;
            this.labLocal.Text = "Local";
            // 
            // labVisitante
            // 
            this.labVisitante.AutoSize = true;
            this.labVisitante.Location = new System.Drawing.Point(409, 45);
            this.labVisitante.Name = "labVisitante";
            this.labVisitante.Size = new System.Drawing.Size(47, 13);
            this.labVisitante.TabIndex = 5;
            this.labVisitante.Text = "Visitante";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labVisitante);
            this.Controls.Add(this.labLocal);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnVisitante);
            this.Controls.Add(this.btnLocal);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLocal;
        private System.Windows.Forms.Button btnVisitante;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label labLocal;
        private System.Windows.Forms.Label labVisitante;
    }
}

