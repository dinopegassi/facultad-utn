﻿namespace TUTORIALlibreria
{
    public class Class1
    {

    }
}